# ChangeLog

## Unreleased

**Added:**

**Changed:**

**Removed:**

**Fixed:**

## 1.0.1

**Fixed:**

* Same ID bug fix
* File type bug fix




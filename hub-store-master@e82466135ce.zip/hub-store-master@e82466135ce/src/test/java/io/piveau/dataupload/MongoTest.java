package io.piveau.dataupload;


class MongoTest {

    /*
      --------------- There are no tests for this application -------------
     */

}
